import json
import pymysql
import os
from datetime import datetime

# RDS 연결 설정
db_host = os.environ['DB_HOST']
db_user = os.environ['DB_USER']
db_password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']

def default_serializer(obj):
    """JSON 직렬화에 사용될 기본 변환기"""
    if isinstance(obj, datetime):
        return obj.strftime('%Y-%m-%d %H:%M:%S')
    raise TypeError(f"Type {type(obj)} not serializable")

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        is_reservation = body.get('is_reservation', False)  # 기본값은 False

        if is_reservation:
            # 예약된 항공편 조회 (user_id만 필요)
            user_id = body.get('user_id')
            if not user_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Invalid input: user_id is required for reservation lookup.')
                }

            # RDS 연결
            connection = pymysql.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                database=db_name,
                cursorclass=pymysql.cursors.DictCursor
            )

            with connection.cursor() as cursor:
                # Reservation 테이블에서 예약된 항공편 조회
                sql_reservation = """
                SELECT f.id, f.departure_location, f.arrival_location, f.departure_date, f.arrival_date, f.airline, f.price, r.user_id
                FROM Reservation r
                JOIN Flight f ON r.flight_id = f.id
                WHERE r.user_id = %s
                """
                cursor.execute(sql_reservation, (user_id,))
                reserved_flights = cursor.fetchall()

            connection.close()

            # 예약된 항공편 반환
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'count': len(reserved_flights),
                    'flights': reserved_flights
                }, default=default_serializer)
            }
        else:
            # 새로운 검색 (departure_location, arrival_location, departure_date 필요)
            departure_location = body.get('departure_location')
            arrival_location = body.get('arrival_location')
            departure_date = body.get('departure_date')
            round_trip = body.get('round_trip')

            if not departure_location or not arrival_location or not departure_date:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Invalid input: departure_location, arrival_location, and departure_date are required.')
                }

            # RDS 연결
            connection = pymysql.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                database=db_name,
                cursorclass=pymysql.cursors.DictCursor
            )

            with connection.cursor() as cursor:
                # 편도 항공편 쿼리
                sql_oneway = """
                SELECT id, departure_date, arrival_date, airline, price
                FROM Flight
                WHERE departure_location = %s
                  AND arrival_location = %s
                  AND DATE(departure_date) = %s
                """
                cursor.execute(sql_oneway, (departure_location, arrival_location, departure_date))
                oneway_flights = cursor.fetchall()

                if round_trip:
                    arrival_date = body.get('arrival_date')
                    sql_return = """
                    SELECT id, departure_date, arrival_date, airline, price
                    FROM Flight
                    WHERE departure_location = %s
                      AND arrival_location = %s
                      AND DATE(departure_date) = %s
                    """
                    cursor.execute(sql_return, (arrival_location, departure_location, arrival_date))
                    return_flights = cursor.fetchall()

                    # 왕복 조합 생성
                    round_trip_flights = []
                    for departure in oneway_flights:
                        for return_flight in return_flights:
                            round_trip_flights.append({
                                "departure": {
                                    "departure_date": departure["departure_date"],
                                    "arrival_date": departure["arrival_date"],
                                    "airline": departure["airline"],
                                    "price": departure["price"],
                                    "id": departure["id"]
                                },
                                "return": {
                                    "departure_date": return_flight["departure_date"],
                                    "arrival_date": return_flight["arrival_date"],
                                    "airline": return_flight["airline"],
                                    "price": return_flight["price"],
                                    "id": return_flight["id"]
                                },
                                "total_price": departure["price"] + return_flight["price"]
                            })

                    round_trip_flights.sort(key=lambda x: x["total_price"])
                    connection.close()

                    # 왕복 데이터 반환
                    return {
                        'statusCode': 200,
                        'body': json.dumps({
                            'count': len(round_trip_flights),
                            'flights': round_trip_flights
                        }, default=default_serializer)
                    }

            connection.close()

            # 편도 데이터를 반환
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'count': len(oneway_flights),
                    'flights': oneway_flights
                }, default=default_serializer)
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
