import json
import pymysql
import os

# RDS 연결 설정
db_host = os.environ['DB_HOST']
db_user = os.environ['DB_USER']
db_password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']

def lambda_handler(event, context):
    try:
        # HTTP 요청에서 body 추출
        body = json.loads(event['body'])
        user_id = body.get('user_id')
        flight_id = body.get('flight_id')

        if not user_id or not flight_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid input: user_id and flight_id are required.')
            }

        # RDS 연결
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )

        with connection.cursor() as cursor:
            # 항공편 가격 가져오기
            price_query = "SELECT price FROM Flight WHERE id = %s"
            cursor.execute(price_query, (flight_id,))
            flight = cursor.fetchone()

            if not flight:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Invalid flight_id.')
                }

            ticket_price = flight['price']
            mileage_to_deduct = int(ticket_price * 0.01)

            # Reservation 테이블에서 삭제
            delete_query = "DELETE FROM Reservation WHERE user_id = %s AND flight_id = %s"
            cursor.execute(delete_query, (user_id, flight_id))

            # User 테이블에서 mileage 감소
            update_mileage_query = "UPDATE User SET mileage = mileage - %s WHERE user_id = %s"
            cursor.execute(update_mileage_query, (mileage_to_deduct, user_id))

            connection.commit()

        connection.close()

        return {
            'statusCode': 200,
            'body': json.dumps('Reservation cancelled and mileage updated successfully.')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
