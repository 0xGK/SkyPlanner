import json
import pymysql
import os

# RDS 연결 설정
db_host = os.environ['DB_HOST']
db_user = os.environ['DB_USER']
db_password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']

def lambda_handler(event, context):
    try:
        # HTTP 요청에서 body 추출
        body = json.loads(event['body'])
        user_id = body.get('user_id')
        try:
            flight_id = int(body.get('flight_id'))  # flight_id를 정수로 변환
        except ValueError:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid flight_id format. Must be an integer.')
            }

        if not user_id or not flight_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid input: user_id and flight_id are required.')
            }

        # RDS 연결
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )
        
        with connection.cursor() as cursor:
            # user_id 유효성 확인
            user_check_sql = "SELECT COUNT(*) AS count FROM User WHERE user_id = %s"
            cursor.execute(user_check_sql, (user_id,))
            user_result = cursor.fetchone()
            if user_result['count'] == 0:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Invalid user_id.')
                }

            # flight_id 유효성 확인 및 ticketPrice 가져오기
            flight_check_sql = "SELECT price FROM Flight WHERE id = %s"
            cursor.execute(flight_check_sql, (flight_id,))
            flight_result = cursor.fetchone()
            if not flight_result:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Invalid flight_id.')
                }
            ticket_price = flight_result['price']

            # 중복 확인
            check_sql = "SELECT COUNT(*) AS count FROM Reservation WHERE user_id = %s AND flight_id = %s"
            cursor.execute(check_sql, (user_id, flight_id))
            result = cursor.fetchone()
            if result['count'] > 0:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Duplicate reservation.')
                }

            # 예약 추가 쿼리
            insert_sql = "INSERT INTO Reservation (user_id, flight_id) VALUES (%s, %s)"
            cursor.execute(insert_sql, (user_id, flight_id))

            # 마일리지 업데이트
            mileage_to_add = int(ticket_price * 0.01)
            update_mileage_sql = "UPDATE User SET mileage = mileage + %s WHERE user_id = %s"
            cursor.execute(update_mileage_sql, (mileage_to_add, user_id))
            connection.commit()
        
        connection.close()

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Reservation added successfully.',
                'mileage_added': mileage_to_add
            })
        }
    except pymysql.IntegrityError:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid input or duplicate reservation.')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
