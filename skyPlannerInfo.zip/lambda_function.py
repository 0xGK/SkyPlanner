import json
import pymysql
import os

# RDS 연결 설정
db_host = os.environ['DB_HOST']
db_user = os.environ['DB_USER']
db_password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']

def lambda_handler(event, context):
    try:
        # HTTP 요청에서 user_id 추출
        body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        user_id = body.get('user_id')

        if not user_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid input: user_id is required.')
            }

        # RDS 연결
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )

        with connection.cursor() as cursor:
            # mileage 조회 쿼리
            sql = "SELECT mileage FROM User WHERE user_id = %s"
            cursor.execute(sql, (user_id,))
            result = cursor.fetchone()

        connection.close()

        if result is None:
            return {
                'statusCode': 404,
                'body': json.dumps('User not found.')
            }

        # mileage 반환
        return {
            'statusCode': 200,
            'body': json.dumps({
                'mileage': result['mileage']
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
