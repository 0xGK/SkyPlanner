import json
import pymysql
import os
import time

# RDS 연결 설정
db_host = os.environ['DB_HOST']
db_user = os.environ['DB_USER']
db_password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']

def lambda_handler(event, context):
        
    try:
        # HTTP 요청에서 action 확인 ('signup' 또는 'login')
        body = json.loads(event['body'])
        action = body.get('action')
        
        if action == 'signup':
            return handle_signup(body)
        elif action == 'login':
            return handle_login(body)
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid action. Use "signup" or "login".')
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }

def handle_signup(body):
    """회원가입 처리"""
    try:
        user_id = body.get('user_id')
        password = body.get('password')
        name = body.get('name')
        pin_number = body.get('pin_number')
        
        if not user_id or not password or not name or not pin_number:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid input: id, password, name, and pin_number are required.')
            }

        # RDS 연결
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )
        
        with connection.cursor() as cursor:
            # user_id 중복 확인
            sql_check = "SELECT COUNT(*) AS count FROM User WHERE user_id = %s"
            cursor.execute(sql_check, (user_id,))
            result = cursor.fetchone()
            
            if result['count'] > 0:
                return {
                    'statusCode': 409,
                    'body': json.dumps('User ID already exists.')
                }

            # 회원가입 쿼리
            sql_insert = "INSERT INTO User (user_id, password, name, pin_number) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql_insert, (user_id, password, name, pin_number))
            connection.commit()
        
        connection.close()

        return {
            'statusCode': 200,
            'body': json.dumps('Signup successful.')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Sign up Error: {str(e)}')
        }


def handle_login(body):
    """로그인 처리"""
    try:
        user_id = body.get('user_id')
        password = body.get('password')

        if not user_id or not password:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid input: id and password are required.')
            }

        # RDS 연결
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            cursorclass=pymysql.cursors.DictCursor
        )
        
        with connection.cursor() as cursor:
            # 사용자 인증 쿼리
            sql = "SELECT password, name, pin_number FROM User WHERE user_id = %s"
            cursor.execute(sql, (user_id,))
            result = cursor.fetchone()
        
        connection.close()

        if result:
            if result['password'] == password:  # 비밀번호 확인 (비밀번호 암호화된 경우 별도 처리 필요)
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': 'Login successful.',
                        'name': result['name'],
                        'pin_number': result['pin_number']
                    })
                }
            else:
                return {
                    'statusCode': 401,
                    'body': json.dumps('Invalid ID or password.')
                }
        else:
            return {
                'statusCode': 401,
                'body': json.dumps('Invalid ID or password.')
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Login Error: {str(e)}')
        }
